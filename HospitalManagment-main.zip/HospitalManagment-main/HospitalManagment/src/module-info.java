/**
 * 
 */
/**
 * 
 */
module HospitalManagment {
	requires java.sql;
	requires java.desktop;
}