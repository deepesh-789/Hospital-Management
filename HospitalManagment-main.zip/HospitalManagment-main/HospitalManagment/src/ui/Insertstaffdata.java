package ui;

public class Insertstaffdata {

}
