package ui;

public class deletestaffid {

}
